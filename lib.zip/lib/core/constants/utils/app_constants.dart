class AppConstants {
  static const baseUrl = '';
}