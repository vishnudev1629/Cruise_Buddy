// import 'package:hive_flutter/hive_flutter.dart';
// part 'user_details_adapter.g.dart';

// @HiveType(typeId: 3)
// class UserDetailsDB {
//   @HiveField(0)
//   dynamic customer_id;

//   UserDetailsDB({
//     this.customer_id,
//   });

//   factory UserDetailsDB.fromJson(Map<String, dynamic> json) {
//     return UserDetailsDB(
//       customer_id: json['customer_id'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = <String, dynamic>{};
//     data['customer_id'] = customer_id;

//     return data;
//   }
// }
